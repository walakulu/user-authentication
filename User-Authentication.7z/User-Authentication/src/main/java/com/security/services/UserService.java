package com.security.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.security.common.Response;
import com.security.model.User;
import com.security.repository.UserRepository;
import com.security.token.management.TokenGenerator;

@RestController
public class UserService {
	@Autowired
	UserRepository userRepository;

	@RequestMapping(method = RequestMethod.POST, value = "/reg")
	public Response userRegistation(@RequestBody User inputUser) {
		String userName = inputUser.getUserName();
		String password = inputUser.getPassword();
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String hashedPassword = passwordEncoder.encode(password);
		User user = new User();
		user.setUserName(userName);
		user.setPassword(hashedPassword);
		userRepository.save(user);
		Response successResponse = new Response();

		successResponse.setStatus("success");

		return successResponse;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/auth")
	public Response userAuthentication(@RequestBody User inputUser) {
		// Data to authenticate
		String userName = inputUser.getUserName();
		String password = inputUser.getPassword();
		// Data from database
		User dbUser = userRepository.findFirstByUserName(userName);
		Response response = new Response();
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		if (dbUser!=null && passwordEncoder.matches(password, dbUser.getPassword())) {
			// Encode new password and store it
			TokenGenerator tokenGenerator = new TokenGenerator();
			String jwt = tokenGenerator.createJWT("001", "hasitha.com", userName, 30000);
			response.setToken(jwt);
			response.setStatus("success");

		} else {
			// Report error
			response.setStatus("fail");
		}

		return response;
	}

}
