package com.security.services;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.security.common.Response;

@RestController
public class ResourceService {
	@RequestMapping(value = "/message")
	public Response getMessage() {
		String msg = "Hi!..You have permisions to access this resource";
		Response response = new Response();
		response.setMsg(msg);
		response.setStatus("Success");
		return response;
	}

}
