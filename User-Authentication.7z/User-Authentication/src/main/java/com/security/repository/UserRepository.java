package com.security.repository;

import org.springframework.data.repository.CrudRepository;

import com.security.model.User;

public interface UserRepository extends CrudRepository<User, Long> {

	User findFirstByUserName(String username);

}
