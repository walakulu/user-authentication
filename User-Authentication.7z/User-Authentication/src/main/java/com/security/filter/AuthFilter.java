package com.security.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

@Component
public class AuthFilter extends GenericFilterBean {

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest request = ((HttpServletRequest) req);
		HttpServletResponse response = ((HttpServletResponse) res);

		String uri = request.getRequestURI();
		String authHeader = request.getHeader("Authorization");

		boolean endPoint = uri.startsWith("/message") || uri.startsWith("/message1") || uri.startsWith("/message2")
				|| uri.startsWith("/message3/");

		if (endPoint) {
			if (authHeader == null || !authHeader.startsWith("Bearer")) {
				response.setStatus(401);
			} else {
				chain.doFilter(request, response);
			}
		} else {
			chain.doFilter(request, response);
		}

	}

}