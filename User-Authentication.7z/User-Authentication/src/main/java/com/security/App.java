package com.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.security.model.User;
import com.security.repository.UserRepository;
import com.security.token.management.TokenDecoder;
import com.security.token.management.TokenGenerator;

@SpringBootApplication
public class App {
	private static final Logger log = LoggerFactory.getLogger(App.class);

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
		/*
		 * TokenGenerator tokenGenerator = new TokenGenerator(); String id =
		 * "001"; // the issuer of the claim. Connect uses it to identify the
		 * application // making the call. String iss = "hasitha.com"; // The
		 * subject of this token. This is the user associated with the //
		 * relevant action, and may not be present if there is no logged in //
		 * user. String subject = "hasitha"; // Expiration time. It contains the
		 * UTC Unix time after which you should // no longer accept this token.
		 * It should be after the issued-at time. long exp = 30000;
		 * 
		 * // We can add what this person(subject) can access using scope claim.
		 * Ex // "scopes": ["explorer", "solar-harvester", "seller"], String jwt
		 * = tokenGenerator.createJWT(id, iss, subject, exp);
		 * System.out.println("Generated Token : " + jwt); TokenDecoder
		 * tokenDecoder = new TokenDecoder(); System.out.
		 * println("Token Decode Started .................................");
		 * tokenDecoder.parseJWT(jwt);
		 */
	}

}
